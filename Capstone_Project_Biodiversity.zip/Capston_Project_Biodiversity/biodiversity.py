{
 "cells": [
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Capstone 2: Biodiversity Project"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Introduction\n",
    "You are a biodiversity analyst working for the National Parks Service.  You're going to help them analyze some data about species at various national parks.\n",
    "\n",
    "Note: The data that you'll be working with for this project is *inspired* by real data, but is mostly fictional."
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Step 1\n",
    "Import the modules that you'll be using in this assignment:\n",
    "- `from matplotlib import pyplot as plt`\n",
    "- `import pandas as pd`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 1,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "from matplotlib import pyplot as plt\n",
    "import pandas as pd"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Step 2\n",
    "You have been given two CSV files. `species_info.csv` with data about different species in our National Parks, including:\n",
    "- The scientific name of each species\n",
    "- The common names of each species\n",
    "- The species conservation status\n",
    "\n",
    "Load the dataset and inspect it:\n",
    "- Load `species_info.csv` into a DataFrame called `species`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "species = pd.read_csv('species_info.csv')"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Inspect each DataFrame using `.head()`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 3,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>category</th>\n",
       "      <th>scientific_name</th>\n",
       "      <th>common_names</th>\n",
       "      <th>conservation_status</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Clethrionomys gapperi gapperi</td>\n",
       "      <td>Gapper's Red-Backed Vole</td>\n",
       "      <td>NaN</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Bos bison</td>\n",
       "      <td>American Bison, Bison</td>\n",
       "      <td>NaN</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Bos taurus</td>\n",
       "      <td>Aurochs, Aurochs, Domestic Cattle (Feral), Dom...</td>\n",
       "      <td>NaN</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Ovis aries</td>\n",
       "      <td>Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)</td>\n",
       "      <td>NaN</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Cervus elaphus</td>\n",
       "      <td>Wapiti Or Elk</td>\n",
       "      <td>NaN</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  category                scientific_name  \\\n",
       "0   Mammal  Clethrionomys gapperi gapperi   \n",
       "1   Mammal                      Bos bison   \n",
       "2   Mammal                     Bos taurus   \n",
       "3   Mammal                     Ovis aries   \n",
       "4   Mammal                 Cervus elaphus   \n",
       "\n",
       "                                        common_names conservation_status  \n",
       "0                           Gapper's Red-Backed Vole                 NaN  \n",
       "1                              American Bison, Bison                 NaN  \n",
       "2  Aurochs, Aurochs, Domestic Cattle (Feral), Dom...                 NaN  \n",
       "3  Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)                 NaN  \n",
       "4                                      Wapiti Or Elk                 NaN  "
      ]
     },
     "execution_count": 3,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "species.head()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Step 3\n",
    "Let's start by learning a bit more about our data.  Answer each of the following questions."
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "How many different species are in the `species` DataFrame?"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 4,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "5541"
      ]
     },
     "execution_count": 4,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "species.scientific_name.nunique()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "What are the different values of `category` in `species`?"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 5,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "array(['Mammal', 'Bird', 'Reptile', 'Amphibian', 'Fish', 'Vascular Plant',\n",
       "       'Nonvascular Plant'], dtype=object)"
      ]
     },
     "execution_count": 5,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "species.category.unique()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "What are the different values of `conservation_status`?"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 6,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "array([nan, 'Species of Concern', 'Endangered', 'Threatened', 'In Recovery'], dtype=object)"
      ]
     },
     "execution_count": 6,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "species.conservation_status.unique()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Step 4\n",
    "Let's start doing some analysis!\n",
    "\n",
    "The column `conservation_status` has several possible values:\n",
    "- `Species of Concern`: declining or appear to be in need of conservation\n",
    "- `Threatened`: vulnerable to endangerment in the near future\n",
    "- `Endangered`: seriously at risk of extinction\n",
    "- `In Recovery`: formerly `Endangered`, but currnetly neither in danger of extinction throughout all or a significant portion of its range\n",
    "\n",
    "We'd like to count up how many species meet each of these criteria.  Use `groupby` to count how many `scientific_name` meet each of these criteria."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 7,
   "metadata": {
    "collapsed": false,
    "scrolled": true
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>conservation_status</th>\n",
       "      <th>scientific_name</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Endangered</td>\n",
       "      <td>15</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>In Recovery</td>\n",
       "      <td>4</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Species of Concern</td>\n",
       "      <td>151</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Threatened</td>\n",
       "      <td>10</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  conservation_status  scientific_name\n",
       "0          Endangered               15\n",
       "1         In Recovery                4\n",
       "2  Species of Concern              151\n",
       "3          Threatened               10"
      ]
     },
     "execution_count": 7,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "species.groupby('conservation_status').scientific_name.nunique().reset_index()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "As we saw before, there are far more than 200 species in the `species` table.  Clearly, only a small number of them are categorized as needing some sort of protection.  The rest have `conservation_status` equal to `None`.  Because `groupby` does not include `None`, we will need to fill in the null values.  We can do this using `.fillna`.  We pass in however we want to fill in our `None` values as an argument.\n",
    "\n",
    "Paste the following code and run it to see replace `None` with `No Intervention`:\n",
    "```python\n",
    "species.fillna('No Intervention', inplace=True)\n",
    "```"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 8,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "species.fillna('No Intervention', inplace=True)"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Great! Now run the same `groupby` as before to see how many species require `No Protection`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 9,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>conservation_status</th>\n",
       "      <th>scientific_name</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Endangered</td>\n",
       "      <td>15</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>In Recovery</td>\n",
       "      <td>4</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>No Intervention</td>\n",
       "      <td>5363</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Species of Concern</td>\n",
       "      <td>151</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>Threatened</td>\n",
       "      <td>10</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  conservation_status  scientific_name\n",
       "0          Endangered               15\n",
       "1         In Recovery                4\n",
       "2     No Intervention             5363\n",
       "3  Species of Concern              151\n",
       "4          Threatened               10"
      ]
     },
     "execution_count": 9,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "species.groupby('conservation_status').scientific_name.nunique().reset_index()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Let's use `plt.bar` to create a bar chart.  First, let's sort the columns by how many species are in each categories.  We can do this using `.sort_values`.  We use the the keyword `by` to indicate which column we want to sort by.\n",
    "\n",
    "Paste the following code and run it to create a new DataFrame called `protection_counts`, which is sorted by `scientific_name`:\n",
    "```python\n",
    "protection_counts = species.groupby('conservation_status')\\\n",
    "    .scientific_name.count().reset_index()\\\n",
    "    .sort_values(by='scientific_name')\n",
    "```"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 10,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "protection_counts = species.groupby('conservation_status')\\\n",
    "    .scientific_name.count().reset_index()\\\n",
    "    .sort_values(by='scientific_name')"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Now let's create a bar chart!\n",
    "1. Start by creating a wide figure with `figsize=(10, 4)`\n",
    "1. Start by creating an axes object called `ax` using `plt.subplot`.\n",
    "2. Create a bar chart whose heights are equal to `scientific_name` column of `protection_counts`.\n",
    "3. Create an x-tick for each of the bars.\n",
    "4. Label each x-tick with the label from `conservation_status` in `protection_counts`\n",
    "5. Label the y-axis `Number of Species`\n",
    "6. Title the graph `Conservation Status by Species`\n",
    "7. Plot the grap using `plt.show()`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 50,
   "metadata": {
    "collapsed": false
   },
   "outputs": [],
   "source": [
    "plt.figure(figsize=(10, 4))\n",
    "ax = plt.subplot()\n",
    "plt.bar(range(len(protection_counts)),\n",
    "        protection_counts.scientific_name.values)\n",
    "ax.set_xticks(range(len(protection_counts)))\n",
    "ax.set_xticklabels(protection_counts.conservation_status.values, ha='center')\n",
    "plt.ylabel('Number of Species')\n",
    "plt.title('Conservation Status\\n by Species')\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Step 4\n",
    "Are certain types of species more likely to be endangered?"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Let's create a new column in `species` called `is_protected`, which is `True` if `conservation_status` is not equal to `No Intervention`, and `False` otherwise."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 63,
   "metadata": {
    "collapsed": false
   },
   "outputs": [],
   "source": [
    "species['is_protected'] = species.conservation_status != 'No Intervention'"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Let's group by *both* `category` and `is_protected`.  Save your results to `category_counts`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 64,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "category_counts = species.groupby(['category', 'is_protected'])\\\n",
    "                        .scientific_name.nunique().reset_index()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Examine `category_count` using `head()`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 65,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>category</th>\n",
       "      <th>is_protected</th>\n",
       "      <th>scientific_name</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Amphibian</td>\n",
       "      <td>False</td>\n",
       "      <td>72</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Amphibian</td>\n",
       "      <td>True</td>\n",
       "      <td>7</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Bird</td>\n",
       "      <td>False</td>\n",
       "      <td>413</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Bird</td>\n",
       "      <td>True</td>\n",
       "      <td>75</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>Fish</td>\n",
       "      <td>False</td>\n",
       "      <td>115</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "    category is_protected  scientific_name\n",
       "0  Amphibian        False               72\n",
       "1  Amphibian         True                7\n",
       "2       Bird        False              413\n",
       "3       Bird         True               75\n",
       "4       Fish        False              115"
      ]
     },
     "execution_count": 65,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "category_counts.head()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {
    "collapsed": true
   },
   "source": [
    "It's going to be easier to view this data if we pivot it.  Using `pivot`, rearange `category_counts` so that:\n",
    "- `columns` is `conservation_status`\n",
    "- `index` is `category`\n",
    "- `values` is `scientific_name`\n",
    "\n",
    "Save your pivoted data to `category_pivot`. Remember to `reset_index()` at the end."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 18,
   "metadata": {
    "collapsed": false
   },
   "outputs": [],
   "source": [
    "category_pivot = category_counts.pivot(columns='is_protected',\n",
    "                                      index='category',\n",
    "                                      values='scientific_name').reset_index()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Examine `category_pivot`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 19,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th>is_protected</th>\n",
       "      <th>category</th>\n",
       "      <th>False</th>\n",
       "      <th>True</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Amphibian</td>\n",
       "      <td>72</td>\n",
       "      <td>7</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Bird</td>\n",
       "      <td>413</td>\n",
       "      <td>75</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Fish</td>\n",
       "      <td>115</td>\n",
       "      <td>11</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>146</td>\n",
       "      <td>30</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>Nonvascular Plant</td>\n",
       "      <td>328</td>\n",
       "      <td>5</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>5</th>\n",
       "      <td>Reptile</td>\n",
       "      <td>73</td>\n",
       "      <td>5</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>6</th>\n",
       "      <td>Vascular Plant</td>\n",
       "      <td>4216</td>\n",
       "      <td>46</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "is_protected           category  False  True\n",
       "0                     Amphibian     72     7\n",
       "1                          Bird    413    75\n",
       "2                          Fish    115    11\n",
       "3                        Mammal    146    30\n",
       "4             Nonvascular Plant    328     5\n",
       "5                       Reptile     73     5\n",
       "6                Vascular Plant   4216    46"
      ]
     },
     "execution_count": 19,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "category_pivot"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Use the `.columns` property to  rename the categories `True` and `False` to something more description:\n",
    "- Leave `category` as `category`\n",
    "- Rename `False` to `not_protected`\n",
    "- Rename `True` to `protected`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 22,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>category</th>\n",
       "      <th>not_protected</th>\n",
       "      <th>protected</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Amphibian</td>\n",
       "      <td>72</td>\n",
       "      <td>7</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Bird</td>\n",
       "      <td>413</td>\n",
       "      <td>75</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Fish</td>\n",
       "      <td>115</td>\n",
       "      <td>11</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>146</td>\n",
       "      <td>30</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>Nonvascular Plant</td>\n",
       "      <td>328</td>\n",
       "      <td>5</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>5</th>\n",
       "      <td>Reptile</td>\n",
       "      <td>73</td>\n",
       "      <td>5</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>6</th>\n",
       "      <td>Vascular Plant</td>\n",
       "      <td>4216</td>\n",
       "      <td>46</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            category  not_protected  protected\n",
       "0          Amphibian             72          7\n",
       "1               Bird            413         75\n",
       "2               Fish            115         11\n",
       "3             Mammal            146         30\n",
       "4  Nonvascular Plant            328          5\n",
       "5            Reptile             73          5\n",
       "6     Vascular Plant           4216         46"
      ]
     },
     "execution_count": 22,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "category_pivot.columns = ['category', 'not_protected', 'protected']\n",
    "category_pivot"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Let's create a new column of `category_pivot` called `percent_protected`, which is equal to `protected` (the number of species that are protected) divided by `protected` plus `not_protected` (the total number of species)."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 82,
   "metadata": {
    "collapsed": false
   },
   "outputs": [],
   "source": [
    "category_pivot['percent_protected'] = (category_pivot.protected /\\\n",
    "(category_pivot.not_protected + category_pivot.protected))"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Examine `category_pivot`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 83,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>category</th>\n",
       "      <th>not_protected</th>\n",
       "      <th>protected</th>\n",
       "      <th>percent_protected</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Amphibian</td>\n",
       "      <td>72</td>\n",
       "      <td>7</td>\n",
       "      <td>0.088608</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Bird</td>\n",
       "      <td>413</td>\n",
       "      <td>75</td>\n",
       "      <td>0.153689</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Fish</td>\n",
       "      <td>115</td>\n",
       "      <td>11</td>\n",
       "      <td>0.087302</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>146</td>\n",
       "      <td>30</td>\n",
       "      <td>0.170455</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>Nonvascular Plant</td>\n",
       "      <td>328</td>\n",
       "      <td>5</td>\n",
       "      <td>0.015015</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>5</th>\n",
       "      <td>Reptile</td>\n",
       "      <td>73</td>\n",
       "      <td>5</td>\n",
       "      <td>0.064103</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>6</th>\n",
       "      <td>Vascular Plant</td>\n",
       "      <td>4216</td>\n",
       "      <td>46</td>\n",
       "      <td>0.010793</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            category  not_protected  protected  percent_protected\n",
       "0          Amphibian             72          7           0.088608\n",
       "1               Bird            413         75           0.153689\n",
       "2               Fish            115         11           0.087302\n",
       "3             Mammal            146         30           0.170455\n",
       "4  Nonvascular Plant            328          5           0.015015\n",
       "5            Reptile             73          5           0.064103\n",
       "6     Vascular Plant           4216         46           0.010793"
      ]
     },
     "execution_count": 83,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "category_pivot"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "##### It looks like species in category `Mammal` are more likely to be endangered than species in `Bird`.  We're going to do a significance test to see if this statement is true.  Before you do the significance test, consider the following questions:\n",
    "- Is the data numerical or categorical?\n",
    "- How many pieces of data are you comparing?"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Based on those answers, you should choose to do a *chi squared test*.  In order to run a chi squared test, we'll need to create a contingency table.  Our contingency table should look like this:\n",
    "\n",
    "||protected|not protected|\n",
    "|-|-|-|\n",
    "|Mammal|?|?|\n",
    "|Bird|?|?|\n",
    "\n",
    "Create a table called `contingency` and fill it in with the correct numbers"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 26,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "contingency = [[30, 146], \n",
    "               [75, 413]]"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "In order to perform our chi square test, we'll need to import the correct function from scipy.  Past the following code and run it:\n",
    "```py\n",
    "from scipy.stats import chi2_contingency\n",
    "```"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 27,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "from scipy.stats import chi2_contingency"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Now run `chi2_contingency` with `contingency`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 29,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.68759480966613362"
      ]
     },
     "execution_count": 29,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "chi2, pval, dof, expected = chi2_contingency(contingency)\n",
    "pval"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "It looks like this difference isn't significant!\n",
    "\n",
    "Let's test another.  Is the difference between `Reptile` and `Mammal` significant?"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 30,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "0.038355590229698977"
      ]
     },
     "execution_count": 30,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "contingency_reptile = [[30, 146], \n",
    "                       [5, 73]]\n",
    "\n",
    "chi2, pval2, dof, expected = chi2_contingency(contingency_reptile)\n",
    "pval2"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Yes! It looks like there is a significant difference between `Reptile` and `Mammal`!"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "# Step 5"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Conservationists have been recording sightings of different species at several national parks for the past 7 days.  They've saved sent you their observations in a file called `observations.csv`.  Load `observations.csv` into a variable called `observations`, then use `head` to view the data."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 32,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>scientific_name</th>\n",
       "      <th>park_name</th>\n",
       "      <th>observations</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Vicia benghalensis</td>\n",
       "      <td>Great Smoky Mountains National Park</td>\n",
       "      <td>68</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Neovison vison</td>\n",
       "      <td>Great Smoky Mountains National Park</td>\n",
       "      <td>77</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Prunus subcordata</td>\n",
       "      <td>Yosemite National Park</td>\n",
       "      <td>138</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Abutilon theophrasti</td>\n",
       "      <td>Bryce National Park</td>\n",
       "      <td>84</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>Githopsis specularioides</td>\n",
       "      <td>Great Smoky Mountains National Park</td>\n",
       "      <td>85</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            scientific_name                            park_name  observations\n",
       "0        Vicia benghalensis  Great Smoky Mountains National Park            68\n",
       "1            Neovison vison  Great Smoky Mountains National Park            77\n",
       "2         Prunus subcordata               Yosemite National Park           138\n",
       "3      Abutilon theophrasti                  Bryce National Park            84\n",
       "4  Githopsis specularioides  Great Smoky Mountains National Park            85"
      ]
     },
     "execution_count": 32,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "observations = pd.read_csv('observations.csv')\n",
    "observations.head()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Some scientists are studying the number of sheep sightings at different national parks.  There are several different scientific names for different types of sheep.  We'd like to know which rows of `species` are referring to sheep.  Notice that the following code will tell us whether or not a word occurs in a string:"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 1,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "True"
      ]
     },
     "execution_count": 1,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Does \"Sheep\" occur in this string?\n",
    "str1 = 'This string contains Sheep'\n",
    "'Sheep' in str1"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 2,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "False"
      ]
     },
     "execution_count": 2,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "# Does \"Sheep\" occur in this string?\n",
    "str2 = 'This string contains Cows'\n",
    "'Sheep' in str2"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Use `apply` and a `lambda` function to create a new column in `species` called `is_sheep` which is `True` if the `common_names` contains `'Sheep'`, and `False` otherwise."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 37,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>category</th>\n",
       "      <th>scientific_name</th>\n",
       "      <th>common_names</th>\n",
       "      <th>conservation_status</th>\n",
       "      <th>is_protected</th>\n",
       "      <th>is_sheep</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Clethrionomys gapperi gapperi</td>\n",
       "      <td>Gapper's Red-Backed Vole</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>False</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Bos bison</td>\n",
       "      <td>American Bison, Bison</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>False</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Bos taurus</td>\n",
       "      <td>Aurochs, Aurochs, Domestic Cattle (Feral), Dom...</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>False</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Ovis aries</td>\n",
       "      <td>Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Cervus elaphus</td>\n",
       "      <td>Wapiti Or Elk</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>False</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "  category                scientific_name  \\\n",
       "0   Mammal  Clethrionomys gapperi gapperi   \n",
       "1   Mammal                      Bos bison   \n",
       "2   Mammal                     Bos taurus   \n",
       "3   Mammal                     Ovis aries   \n",
       "4   Mammal                 Cervus elaphus   \n",
       "\n",
       "                                        common_names conservation_status  \\\n",
       "0                           Gapper's Red-Backed Vole     No Intervention   \n",
       "1                              American Bison, Bison     No Intervention   \n",
       "2  Aurochs, Aurochs, Domestic Cattle (Feral), Dom...     No Intervention   \n",
       "3  Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)     No Intervention   \n",
       "4                                      Wapiti Or Elk     No Intervention   \n",
       "\n",
       "  is_protected is_sheep  \n",
       "0        False    False  \n",
       "1        False    False  \n",
       "2        False    False  \n",
       "3        False     True  \n",
       "4        False    False  "
      ]
     },
     "execution_count": 37,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "species['is_sheep'] = species.common_names.apply(lambda x: 'Sheep' in x)\n",
    "species.head()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Select the rows of `species` where `is_sheep` is `True` and examine the results."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 38,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>category</th>\n",
       "      <th>scientific_name</th>\n",
       "      <th>common_names</th>\n",
       "      <th>conservation_status</th>\n",
       "      <th>is_protected</th>\n",
       "      <th>is_sheep</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Ovis aries</td>\n",
       "      <td>Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1139</th>\n",
       "      <td>Vascular Plant</td>\n",
       "      <td>Rumex acetosella</td>\n",
       "      <td>Sheep Sorrel, Sheep Sorrell</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2233</th>\n",
       "      <td>Vascular Plant</td>\n",
       "      <td>Festuca filiformis</td>\n",
       "      <td>Fineleaf Sheep Fescue</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3014</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Ovis canadensis</td>\n",
       "      <td>Bighorn Sheep, Bighorn Sheep</td>\n",
       "      <td>Species of Concern</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3758</th>\n",
       "      <td>Vascular Plant</td>\n",
       "      <td>Rumex acetosella</td>\n",
       "      <td>Common Sheep Sorrel, Field Sorrel, Red Sorrel,...</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3761</th>\n",
       "      <td>Vascular Plant</td>\n",
       "      <td>Rumex paucifolius</td>\n",
       "      <td>Alpine Sheep Sorrel, Fewleaved Dock, Meadow Dock</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4091</th>\n",
       "      <td>Vascular Plant</td>\n",
       "      <td>Carex illota</td>\n",
       "      <td>Sheep Sedge, Smallhead Sedge</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4383</th>\n",
       "      <td>Vascular Plant</td>\n",
       "      <td>Potentilla ovina var. ovina</td>\n",
       "      <td>Sheep Cinquefoil</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4446</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Ovis canadensis sierrae</td>\n",
       "      <td>Sierra Nevada Bighorn Sheep</td>\n",
       "      <td>Endangered</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            category              scientific_name  \\\n",
       "3             Mammal                   Ovis aries   \n",
       "1139  Vascular Plant             Rumex acetosella   \n",
       "2233  Vascular Plant           Festuca filiformis   \n",
       "3014          Mammal              Ovis canadensis   \n",
       "3758  Vascular Plant             Rumex acetosella   \n",
       "3761  Vascular Plant            Rumex paucifolius   \n",
       "4091  Vascular Plant                 Carex illota   \n",
       "4383  Vascular Plant  Potentilla ovina var. ovina   \n",
       "4446          Mammal      Ovis canadensis sierrae   \n",
       "\n",
       "                                           common_names conservation_status  \\\n",
       "3     Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)     No Intervention   \n",
       "1139                        Sheep Sorrel, Sheep Sorrell     No Intervention   \n",
       "2233                              Fineleaf Sheep Fescue     No Intervention   \n",
       "3014                       Bighorn Sheep, Bighorn Sheep  Species of Concern   \n",
       "3758  Common Sheep Sorrel, Field Sorrel, Red Sorrel,...     No Intervention   \n",
       "3761   Alpine Sheep Sorrel, Fewleaved Dock, Meadow Dock     No Intervention   \n",
       "4091                       Sheep Sedge, Smallhead Sedge     No Intervention   \n",
       "4383                                   Sheep Cinquefoil     No Intervention   \n",
       "4446                        Sierra Nevada Bighorn Sheep          Endangered   \n",
       "\n",
       "     is_protected is_sheep  \n",
       "3           False     True  \n",
       "1139        False     True  \n",
       "2233        False     True  \n",
       "3014         True     True  \n",
       "3758        False     True  \n",
       "3761        False     True  \n",
       "4091        False     True  \n",
       "4383        False     True  \n",
       "4446         True     True  "
      ]
     },
     "execution_count": 38,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "species[species.is_sheep]"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Many of the results are actually plants.  Select the rows of `species` where `is_sheep` is `True` and `category` is `Mammal`.  Save the results to the variable `sheep_species`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 43,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>category</th>\n",
       "      <th>scientific_name</th>\n",
       "      <th>common_names</th>\n",
       "      <th>conservation_status</th>\n",
       "      <th>is_protected</th>\n",
       "      <th>is_sheep</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Ovis aries</td>\n",
       "      <td>Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3014</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Ovis canadensis</td>\n",
       "      <td>Bighorn Sheep, Bighorn Sheep</td>\n",
       "      <td>Species of Concern</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4446</th>\n",
       "      <td>Mammal</td>\n",
       "      <td>Ovis canadensis sierrae</td>\n",
       "      <td>Sierra Nevada Bighorn Sheep</td>\n",
       "      <td>Endangered</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "     category          scientific_name  \\\n",
       "3      Mammal               Ovis aries   \n",
       "3014   Mammal          Ovis canadensis   \n",
       "4446   Mammal  Ovis canadensis sierrae   \n",
       "\n",
       "                                           common_names conservation_status  \\\n",
       "3     Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)     No Intervention   \n",
       "3014                       Bighorn Sheep, Bighorn Sheep  Species of Concern   \n",
       "4446                        Sierra Nevada Bighorn Sheep          Endangered   \n",
       "\n",
       "     is_protected is_sheep  \n",
       "3           False     True  \n",
       "3014         True     True  \n",
       "4446         True     True  "
      ]
     },
     "execution_count": 43,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "sheep_species = species[(species.is_sheep) & (species.category == 'Mammal')]\n",
    "sheep_species"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Now merge `sheep_species` with `observations` to get a DataFrame with observations of sheep.  Save this DataFrame as `sheep_observations`."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 44,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>scientific_name</th>\n",
       "      <th>park_name</th>\n",
       "      <th>observations</th>\n",
       "      <th>category</th>\n",
       "      <th>common_names</th>\n",
       "      <th>conservation_status</th>\n",
       "      <th>is_protected</th>\n",
       "      <th>is_sheep</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Ovis canadensis</td>\n",
       "      <td>Yellowstone National Park</td>\n",
       "      <td>219</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Bighorn Sheep, Bighorn Sheep</td>\n",
       "      <td>Species of Concern</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Ovis canadensis</td>\n",
       "      <td>Bryce National Park</td>\n",
       "      <td>109</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Bighorn Sheep, Bighorn Sheep</td>\n",
       "      <td>Species of Concern</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Ovis canadensis</td>\n",
       "      <td>Yosemite National Park</td>\n",
       "      <td>117</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Bighorn Sheep, Bighorn Sheep</td>\n",
       "      <td>Species of Concern</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Ovis canadensis</td>\n",
       "      <td>Great Smoky Mountains National Park</td>\n",
       "      <td>48</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Bighorn Sheep, Bighorn Sheep</td>\n",
       "      <td>Species of Concern</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>4</th>\n",
       "      <td>Ovis canadensis sierrae</td>\n",
       "      <td>Yellowstone National Park</td>\n",
       "      <td>67</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Sierra Nevada Bighorn Sheep</td>\n",
       "      <td>Endangered</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>5</th>\n",
       "      <td>Ovis canadensis sierrae</td>\n",
       "      <td>Yosemite National Park</td>\n",
       "      <td>39</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Sierra Nevada Bighorn Sheep</td>\n",
       "      <td>Endangered</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>6</th>\n",
       "      <td>Ovis canadensis sierrae</td>\n",
       "      <td>Bryce National Park</td>\n",
       "      <td>22</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Sierra Nevada Bighorn Sheep</td>\n",
       "      <td>Endangered</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>7</th>\n",
       "      <td>Ovis canadensis sierrae</td>\n",
       "      <td>Great Smoky Mountains National Park</td>\n",
       "      <td>25</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Sierra Nevada Bighorn Sheep</td>\n",
       "      <td>Endangered</td>\n",
       "      <td>True</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>8</th>\n",
       "      <td>Ovis aries</td>\n",
       "      <td>Yosemite National Park</td>\n",
       "      <td>126</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>9</th>\n",
       "      <td>Ovis aries</td>\n",
       "      <td>Great Smoky Mountains National Park</td>\n",
       "      <td>76</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>10</th>\n",
       "      <td>Ovis aries</td>\n",
       "      <td>Bryce National Park</td>\n",
       "      <td>119</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>11</th>\n",
       "      <td>Ovis aries</td>\n",
       "      <td>Yellowstone National Park</td>\n",
       "      <td>221</td>\n",
       "      <td>Mammal</td>\n",
       "      <td>Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)</td>\n",
       "      <td>No Intervention</td>\n",
       "      <td>False</td>\n",
       "      <td>True</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "            scientific_name                            park_name  \\\n",
       "0           Ovis canadensis            Yellowstone National Park   \n",
       "1           Ovis canadensis                  Bryce National Park   \n",
       "2           Ovis canadensis               Yosemite National Park   \n",
       "3           Ovis canadensis  Great Smoky Mountains National Park   \n",
       "4   Ovis canadensis sierrae            Yellowstone National Park   \n",
       "5   Ovis canadensis sierrae               Yosemite National Park   \n",
       "6   Ovis canadensis sierrae                  Bryce National Park   \n",
       "7   Ovis canadensis sierrae  Great Smoky Mountains National Park   \n",
       "8                Ovis aries               Yosemite National Park   \n",
       "9                Ovis aries  Great Smoky Mountains National Park   \n",
       "10               Ovis aries                  Bryce National Park   \n",
       "11               Ovis aries            Yellowstone National Park   \n",
       "\n",
       "    observations category                                       common_names  \\\n",
       "0            219   Mammal                       Bighorn Sheep, Bighorn Sheep   \n",
       "1            109   Mammal                       Bighorn Sheep, Bighorn Sheep   \n",
       "2            117   Mammal                       Bighorn Sheep, Bighorn Sheep   \n",
       "3             48   Mammal                       Bighorn Sheep, Bighorn Sheep   \n",
       "4             67   Mammal                        Sierra Nevada Bighorn Sheep   \n",
       "5             39   Mammal                        Sierra Nevada Bighorn Sheep   \n",
       "6             22   Mammal                        Sierra Nevada Bighorn Sheep   \n",
       "7             25   Mammal                        Sierra Nevada Bighorn Sheep   \n",
       "8            126   Mammal  Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)   \n",
       "9             76   Mammal  Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)   \n",
       "10           119   Mammal  Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)   \n",
       "11           221   Mammal  Domestic Sheep, Mouflon, Red Sheep, Sheep (Feral)   \n",
       "\n",
       "   conservation_status is_protected is_sheep  \n",
       "0   Species of Concern         True     True  \n",
       "1   Species of Concern         True     True  \n",
       "2   Species of Concern         True     True  \n",
       "3   Species of Concern         True     True  \n",
       "4           Endangered         True     True  \n",
       "5           Endangered         True     True  \n",
       "6           Endangered         True     True  \n",
       "7           Endangered         True     True  \n",
       "8      No Intervention        False     True  \n",
       "9      No Intervention        False     True  \n",
       "10     No Intervention        False     True  \n",
       "11     No Intervention        False     True  "
      ]
     },
     "execution_count": 44,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "sheep_observations = observations.merge(sheep_species)\n",
    "sheep_observations"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "How many total sheep observations (across all three species) were made at each national park?  Use `groupby` to get the `sum` of `observations` for each `park_name`.  Save your answer to `obs_by_park`.\n",
    "\n",
    "This is the total number of sheep observed in each park over the past 7 days."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 47,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/html": [
       "<div>\n",
       "<table border=\"1\" class=\"dataframe\">\n",
       "  <thead>\n",
       "    <tr style=\"text-align: right;\">\n",
       "      <th></th>\n",
       "      <th>park_name</th>\n",
       "      <th>observations</th>\n",
       "    </tr>\n",
       "  </thead>\n",
       "  <tbody>\n",
       "    <tr>\n",
       "      <th>0</th>\n",
       "      <td>Bryce National Park</td>\n",
       "      <td>250</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>1</th>\n",
       "      <td>Great Smoky Mountains National Park</td>\n",
       "      <td>149</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>2</th>\n",
       "      <td>Yellowstone National Park</td>\n",
       "      <td>507</td>\n",
       "    </tr>\n",
       "    <tr>\n",
       "      <th>3</th>\n",
       "      <td>Yosemite National Park</td>\n",
       "      <td>282</td>\n",
       "    </tr>\n",
       "  </tbody>\n",
       "</table>\n",
       "</div>"
      ],
      "text/plain": [
       "                             park_name  observations\n",
       "0                  Bryce National Park           250\n",
       "1  Great Smoky Mountains National Park           149\n",
       "2            Yellowstone National Park           507\n",
       "3               Yosemite National Park           282"
      ]
     },
     "execution_count": 47,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "obs_by_park = sheep_observations.groupby('park_name').observations.sum().reset_index()\n",
    "obs_by_park"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Create a bar chart showing the different number of observations per week at each park.\n",
    "\n",
    "1. Start by creating a wide figure with `figsize=(16, 4)`\n",
    "1. Start by creating an axes object called `ax` using `plt.subplot`.\n",
    "2. Create a bar chart whose heights are equal to `observations` column of `obs_by_park`.\n",
    "3. Create an x-tick for each of the bars.\n",
    "4. Label each x-tick with the label from `park_name` in `obs_by_park`\n",
    "5. Label the y-axis `Number of Observations`\n",
    "6. Title the graph `Observations of Sheep per Week`\n",
    "7. Plot the grap using `plt.show()`"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 49,
   "metadata": {
    "collapsed": false
   },
   "outputs": [],
   "source": [
    "plt.figure(figsize=(16, 4))\n",
    "ax = plt.subplot()\n",
    "plt.bar(range(len(obs_by_park)),\n",
    "       obs_by_park.observations.values)\n",
    "ax.set_xticks(range(len(obs_by_park)))\n",
    "ax.set_xticklabels(obs_by_park.park_name.values, ha='center')\n",
    "plt.ylabel('Number of Observations')\n",
    "plt.title('Observations of Sheep Per Week')\n",
    "plt.show()"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "Our scientists know that 15% of sheep at Bryce National Park have foot and mouth disease.  Park rangers at Yellowstone National Park have been running a program to reduce the rate of foot and mouth disease at that park.  The scientists want to test whether or not this program is working.  They want to be able to detect reductions of at least 5 percentage point.  For instance, if 10% of sheep in Yellowstone have foot and mouth disease, they'd like to be able to know this, with confidence.\n",
    "\n",
    "Use the sample size calculator at <a href=\"https://www.optimizely.com/sample-size-calculator/\">Optimizely</a> to calculate the number of sheep that they would need to observe from each park.  Use the default level of significance (90%).\n",
    "\n",
    "Remember that \"Minimum Detectable Effect\" is a percent of the baseline."
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 51,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "33.333333333333336"
      ]
     },
     "execution_count": 51,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "minimum_detectable_effect = 100 * 0.05 / 0.15\n",
    "minimum_detectable_effect"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 52,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "baseline = 15"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 54,
   "metadata": {
    "collapsed": true
   },
   "outputs": [],
   "source": [
    "sample_size_per_variant = 510"
   ]
  },
  {
   "cell_type": "markdown",
   "metadata": {},
   "source": [
    "How many weeks would you need to observe sheep at Bryce National Park in order to observe enough sheep?  How many weeks would you need to observe at Yellowstone National Park to observe enough sheep?"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 59,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "2.04"
      ]
     },
     "execution_count": 59,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "bryce = 510 / 250\n",
    "bryce"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": 61,
   "metadata": {
    "collapsed": false
   },
   "outputs": [
    {
     "data": {
      "text/plain": [
       "1.0059171597633136"
      ]
     },
     "execution_count": 61,
     "metadata": {},
     "output_type": "execute_result"
    }
   ],
   "source": [
    "yellowstone = 510 / 507\n",
    "yellowstone"
   ]
  }
 ],
 "metadata": {
  "anaconda-cloud": {},
  "kernelspec": {
   "display_name": "Python [Root]",
   "language": "python",
   "name": "Python [Root]"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.5.2"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 2
}
